//
//  ContactModel.swift
//  Chatterbox
//
//  Created by Александра Кострова on 28.06.2023.
//

import Foundation

struct Contacts {
    let name: String
    let email: String
}
