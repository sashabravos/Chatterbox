//
//  NotificationExstensions.swift
//  Chatterbox
//
//  Created by Александра Кострова on 27.06.2023.
//

import Foundation

extension Notification.Name {
    static let didLogInNotification = Notification.Name("didLogInNotification")
}
